let alarmTime = null;

function updateClock(){

    let now = new Date();

    let hours = now.getHours().toString().padStart(2,'0');
    let minutes = now.getMinutes().toString().padStart(2,'0');
    let seconds = now.getSeconds().toString().padStart(2,'0');

    let currentTime = `${hours}:${minutes}:${seconds}`;

    document.getElementById("clock").textContent = currentTime;

    if(alarmTime === `${hours}:${minutes}`){
        document.getElementById("alarmSound").play();
    }

}

setInterval(updateClock,1000);

function setAlarm(){

    alarmTime = document.getElementById("alarmTime").value;

    document.getElementById("message").textContent =
    "Alarm set for " + alarmTime;

}